import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Prime Spotter",
  description: "Multi-timeframe market analysis and trade planning dashboard"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
