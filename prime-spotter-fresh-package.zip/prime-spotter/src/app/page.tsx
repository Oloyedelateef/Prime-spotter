 "use client";

import { useCallback, useEffect, useState } from "react";
import { Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, RefreshCw, ShieldCheck } from "lucide-react";

type Candle = { datetime: string; open: number; high: number; low: number; close: number };
type Analysis = {
  symbol: string; price: number; updatedAt: string;
  trend: string; structure: string; setup: string; confirmation: string;
  signal: "BUY" | "SELL" | "WAIT"; entry: number | null; stopLoss: number | null;
  takeProfit: number | null; rr: string; reasons: string[];
};
type MarketResponse = { analysis?: Analysis; error?: string; source?: string };
type NewsEvent = { title: string; currency: string; impact: string; time: string };

const symbols = ["XAU/USD", "EUR/USD", "GBP/USD", "USD/JPY"];

function fmt(value: number | null) {
  if (value === null || !Number.isFinite(value)) return "—";
  return value.toFixed(value > 100 ? 2 : 5);
}

export default function Home() {
  const [symbol, setSymbol] = useState("XAU/USD");
  const [data, setData] = useState<Analysis | null>(null);
  const [events, setEvents] = useState<NewsEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [lastChecked, setLastChecked] = useState("");

  const load = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const [marketRes, newsRes] = await Promise.all([
        fetch(`/api/market?symbol=${encodeURIComponent(symbol)}`, { cache: "no-store" }),
        fetch("/api/news", { cache: "no-store" })
      ]);
      const market: MarketResponse = await marketRes.json();
      const news = await newsRes.json();
      if (!marketRes.ok || !market.analysis) throw new Error(market.error || "Market data unavailable.");
      setData(market.analysis);
      setEvents(Array.isArray(news.events) ? news.events : []);
      setLastChecked(new Date().toLocaleTimeString());
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to load market data.");
    } finally { setLoading(false); }
  }, [symbol]);

  useEffect(() => { void load(); }, [load]);

  const upcoming = events.filter(e => {
    const t = new Date(e.time).getTime();
    return Number.isFinite(t) && t >= Date.now() - 15 * 60_000 && t <= Date.now() + 60 * 60_000;
  });
  const newsBlocked = upcoming.some(e => e.impact.toLowerCase() === "high" &&
    (e.currency.toUpperCase() === "USD" || symbol.includes(e.currency.toUpperCase()) ||
     (symbol === "XAU/USD" && e.currency.toUpperCase() === "USD")));

  return (
    <main className="shell">
      <header className="topbar">
        <div className="brand"><div className="brandMark">P</div><div><strong>PRIME SPOTTER</strong><span>PRECISION MARKET INTELLIGENCE</span></div></div>
        <div className="topActions"><span className="liveDot">DATA CONNECTION</span><button className="refresh" onClick={() => void load()} disabled={loading}><RefreshCw size={16} className={loading ? "spin" : ""}/> Refresh</button></div>
      </header>

      <section className="hero">
        <div><p className="eyebrow">MULTI-TIMEFRAME TRADING DESK</p><h1>See the setup.<br/><em>Confirm the entry.</em></h1><p className="sub">H4 trend · H1 structure · M15 setup · M30 entry confirmation</p></div>
        <div className="symbolPicker"><label htmlFor="symbol">INSTRUMENT</label><select id="symbol" value={symbol} onChange={e => setSymbol(e.target.value)}>{symbols.map(s => <option key={s}>{s}</option>)}</select></div>
      </section>

      {error && <div className="error"><AlertTriangle size={18}/><span>{error} Check your Twelve Data API key, plan limits and symbol availability.</span></div>}
      {newsBlocked && <div className="warning"><AlertTriangle size={18}/><span>HIGH-IMPACT NEWS WINDOW: new entries are blocked by the configured event calendar. Verify the event time and currency.</span></div>}

      <section className="signalPanel">
        <div className="signalHead"><div><p className="eyebrow">CURRENT TRADE DECISION</p><h2>{data?.signal ?? "WAIT"}</h2></div><div className={`signalBadge ${(data?.signal ?? "WAIT").toLowerCase()}`}>{data?.signal === "BUY" ? <ArrowUpRight/> : data?.signal === "SELL" ? <ArrowDownRight/> : <Activity/>}{data?.signal ?? "WAIT"}</div></div>
        <div className="priceLine"><span>{symbol}</span><strong>{data ? fmt(data.price) : "—"}</strong><small>{data ? `Updated ${new Date(data.updatedAt).toLocaleString()}` : "Waiting for market data"}</small></div>
        <div className="levels">
          <div><span>ENTRY</span><b>{fmt(data?.entry ?? null)}</b></div>
          <div><span>STOP LOSS</span><b className="red">{fmt(data?.stopLoss ?? null)}</b></div>
          <div><span>TAKE PROFIT</span><b className="green">{fmt(data?.takeProfit ?? null)}</b></div>
          <div><span>RISK / REWARD</span><b>{data?.rr ?? "Minimum 1:2"}</b></div>
        </div>
        {newsBlocked && <p className="blockedNote">Signal overridden to WAIT during the configured high-impact news window.</p>}
      </section>

      <section className="grid4">
        <div className="tile"><span>H4 · DIRECTION</span><strong>{data?.trend ?? "—"}</strong><small>Primary trend filter</small></div>
        <div className="tile"><span>H1 · STRUCTURE</span><strong>{data?.structure ?? "—"}</strong><small>Market structure context</small></div>
        <div className="tile"><span>M15 · SETUP</span><strong>{data?.setup ?? "—"}</strong><small>Potential setup detection</small></div>
        <div className="tile"><span>M30 · CONFIRMATION</span><strong>{data?.confirmation ?? "—"}</strong><small>Entry confirmation</small></div>
      </section>

      <section className="lowerGrid">
        <div className="card"><div className="cardTitle"><h3>Analysis notes</h3><span className="muted">RULE-BASED</span></div>
          {data?.reasons?.length ? <ul>{data.reasons.map((r,i)=><li key={i}>{r}</li>)}</ul> : <p className="muted">Analysis will appear when market data loads.</p>}
          <div className="rule"><ShieldCheck size={17}/><span>Signals require multi-timeframe alignment and at least 1:2 reward-to-risk.</span></div>
        </div>
        <div className="card"><div className="cardTitle"><h3>News protection</h3><span className="muted">EVENT CALENDAR</span></div>
          {events.length ? <div className="events">{events.map((e,i)=><div className="event" key={i}><div><b>{e.title}</b><small>{e.currency} · {e.impact.toUpperCase()}</small></div><time>{new Date(e.time).toLocaleString()}</time></div>)}</div> : <p className="muted">No events configured. Add high-impact events to NEWS_EVENTS_JSON in Vercel. This starter package does not claim to have a live economic-news feed.</p>}
        </div>
      </section>

      <footer><span>PRIME SPOTTER · {lastChecked ? `Last checked ${lastChecked}` : "Awaiting first update"}</span><span>Decision support only · Verify every trade before execution</span></footer>
      <p className="disclaimer">This dashboard is an experimental rule-based analysis tool, not an automated trading system or financial advice. Market-data availability, indicator calculations and news schedules must be independently verified. It does not place trades.</p>
    </main>
  );
}
