import { NextResponse } from "next/server";
export const dynamic = "force-dynamic";
export const revalidate = 0;

type Event = { title:string; currency:string; impact:string; time:string };
export async function GET() {
  try {
    const raw = process.env.NEWS_EVENTS_JSON || "[]";
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) throw new Error("NEWS_EVENTS_JSON must be a JSON array.");
    const events = (parsed as Event[]).filter(e =>
      e && typeof e.title==="string" && typeof e.currency==="string" &&
      typeof e.impact==="string" && typeof e.time==="string" && Number.isFinite(Date.parse(e.time))
    ).sort((a,b)=>Date.parse(a.time)-Date.parse(b.time));
    return NextResponse.json({events},{headers:{"Cache-Control":"no-store, max-age=0"}});
  } catch {
    return NextResponse.json({events:[],warning:"Invalid NEWS_EVENTS_JSON. Use a valid JSON array."},{status:200});
  }
}
