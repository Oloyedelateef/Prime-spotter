import { NextRequest, NextResponse } from "next/server";
import { analyze } from "@/lib/analyze";
import { getCandles } from "@/lib/market";

export const dynamic = "force-dynamic";
export const revalidate = 0;

const ALLOWED = new Set(["XAU/USD","EUR/USD","GBP/USD","USD/JPY"]);

export async function GET(request: NextRequest) {
  const symbol = request.nextUrl.searchParams.get("symbol") || "XAU/USD";
  if (!ALLOWED.has(symbol)) return NextResponse.json({error:"Unsupported instrument."},{status:400});
  try {
    const [h4,h1,m15,m30] = await Promise.all([
      getCandles(symbol,"4h",100), getCandles(symbol,"1h",100),
      getCandles(symbol,"15min",100), getCandles(symbol,"30min",100)
    ]);
    const analysis = analyze(symbol,h4,h1,m15,m30);
    return NextResponse.json({analysis,source:"Twelve Data"},{headers:{"Cache-Control":"no-store, max-age=0"}});
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unexpected market-data error.";
    return NextResponse.json({error:message},{status:502,headers:{"Cache-Control":"no-store, max-age=0"}});
  }
}
