export type Candle = { datetime: string; open: number; high: number; low: number; close: number };
const BASE = "https://api.twelvedata.com";

export async function getCandles(symbol: string, interval: string, outputsize = 100): Promise<Candle[]> {
  const key = process.env.TWELVE_DATA_API_KEY;
  if (!key) throw new Error("TWELVE_DATA_API_KEY is missing. Add it to Vercel Environment Variables.");
  const url = new URL(`${BASE}/time_series`);
  url.searchParams.set("symbol", symbol);
  url.searchParams.set("interval", interval);
  url.searchParams.set("outputsize", String(outputsize));
  url.searchParams.set("apikey", key);
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) throw new Error(`Market-data provider returned HTTP ${response.status}.`);
  const json = await response.json();
  if (json.status === "error" || !Array.isArray(json.values)) {
    throw new Error(json.message || json.code || "No candle data returned for this symbol and interval.");
  }
  return json.values.map((v: Record<string,string>) => ({
    datetime: v.datetime, open: Number(v.open), high: Number(v.high),
    low: Number(v.low), close: Number(v.close)
  })).reverse();
}

export function ema(values: number[], period: number): number {
  if (values.length < period) return NaN;
  const k = 2 / (period + 1);
  let result = values.slice(0, period).reduce((a,b)=>a+b,0) / period;
  for (const value of values.slice(period)) result = value * k + result * (1-k);
  return result;
}
