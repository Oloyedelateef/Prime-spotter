import { Candle, ema } from "./market";

export type TradeAnalysis = {
  symbol: string; price: number; updatedAt: string; trend: string; structure: string;
  setup: string; confirmation: string; signal: "BUY"|"SELL"|"WAIT";
  entry: number|null; stopLoss: number|null; takeProfit: number|null;
  rr: string; reasons: string[];
};

function direction(c: Candle[]): "BULLISH"|"BEARISH"|"NEUTRAL" {
  const closes = c.map(x=>x.close);
  const fast = ema(closes,20), slow = ema(closes,50), last = closes[closes.length-1];
  if (last > fast && fast > slow) return "BULLISH";
  if (last < fast && fast < slow) return "BEARISH";
  return "NEUTRAL";
}

export function analyze(symbol:string,h4:Candle[],h1:Candle[],m15:Candle[],m30:Candle[]):TradeAnalysis {
  const price = m30[m30.length-1].close;
  const trend = direction(h4);
  const h1Direction = direction(h1);
  const structure = h1Direction === "BULLISH" ? "Higher-momentum bias" : h1Direction === "BEARISH" ? "Lower-momentum bias" : "Mixed / range";
  const recent15 = m15.slice(-6,-1);
  const last15 = m15[m15.length-1];
  const priorHigh = Math.max(...recent15.map(c=>c.high));
  const priorLow = Math.min(...recent15.map(c=>c.low));
  const setup = last15.close > priorHigh ? "Bullish breakout" : last15.close < priorLow ? "Bearish breakdown" : "No confirmed breakout";
  const last30 = m30[m30.length-1];
  const confirmation = last30.close > last30.open ? "Bullish candle" : last30.close < last30.open ? "Bearish candle" : "Neutral candle";
  let signal:"BUY"|"SELL"|"WAIT" = "WAIT";
  if (trend==="BULLISH" && h1Direction==="BULLISH" && setup==="Bullish breakout" && last30.close>last30.open) signal="BUY";
  if (trend==="BEARISH" && h1Direction==="BEARISH" && setup==="Bearish breakdown" && last30.close<last30.open) signal="SELL";

  const recent = m30.slice(-14);
  const atr = recent.reduce((sum,c)=>sum+(c.high-c.low),0)/recent.length;
  let entry:number|null=null, stopLoss:number|null=null, takeProfit:number|null=null;
  if (signal==="BUY") { entry=price; stopLoss=price-1.5*atr; takeProfit=price+3*atr; }
  if (signal==="SELL") { entry=price; stopLoss=price+1.5*atr; takeProfit=price-3*atr; }
  const reasons = [
    `H4 EMA trend filter: ${trend}.`,
    `H1 EMA momentum filter: ${h1Direction}.`,
    `M15 breakout check: ${setup}.`,
    `M30 candle check: ${confirmation}.`,
    "Stop distance uses a simple recent M30 average range; targets are set at 2R."
  ];
  return {symbol,price,updatedAt:new Date().toISOString(),trend,structure,setup,confirmation,signal,entry,stopLoss,takeProfit,rr:signal==="WAIT"?"—":"1:2",reasons};
}
