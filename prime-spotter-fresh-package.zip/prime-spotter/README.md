# Prime Spotter — fresh starter package

A fresh Next.js 14 + TypeScript dashboard for multi-timeframe market analysis.

## Included

- Instruments: XAU/USD, EUR/USD, GBP/USD, USD/JPY
- H4 trend filter and H1 momentum/structure context
- M15 breakout check
- M30 candle-direction confirmation
- Rule-based BUY / SELL / WAIT output
- Entry, stop-loss and 2R take-profit calculation
- Manual high-impact news blackout configuration
- Server-side Twelve Data integration
- Dynamic market API route with no-store caching and explicit error responses
- Responsive dashboard

## Important limitations — read before live use

1. The signal logic is a **starter heuristic**, not a validated trading strategy. It uses EMA alignment, a simple M15 breakout check, and M30 candle direction. It does not implement discretionary market structure, liquidity, order blocks, or a backtested scalping model.
2. The news filter is **manual** in this package. It reads `NEWS_EVENTS_JSON`; it is not an automatic economic calendar feed. Do not rely on it as the sole protection against news.
3. TradingView is not used as an unrestricted data API. The app requests OHLC data server-side from Twelve Data.
4. The market endpoint makes four Twelve Data requests per refresh (4h, 1h, 15min, 30min). Check your Twelve Data plan and symbol/interval entitlements before frequent use. The UI refresh is manual; it does not poll continuously.
5. This app does not connect to a broker, place trades, or copy trades.
6. Do not use signals on a funded/live account without independent validation, broker rule checks, and demo testing.

## Run locally

Requires Node.js 20 or later.

```bash
npm install
cp .env.example .env.local
```

Put your Twelve Data key in `.env.local`:

```env
TWELVE_DATA_API_KEY=your_real_key_here
NEWS_EVENTS_JSON=[]
```

Then:

```bash
npm run dev
```

Open http://localhost:3000.

## Deploy to Vercel

1. Upload/import this project into your GitHub repository.
2. In Vercel, import the existing GitHub repository.
3. Add `TWELVE_DATA_API_KEY` in **Project → Settings → Environment Variables** for Production, Preview and Development as needed.
4. Optionally add `NEWS_EVENTS_JSON` as a valid JSON array. Example:

```json
[
  {
    "title": "US CPI",
    "currency": "USD",
    "impact": "high",
    "time": "2026-12-10T13:30:00Z"
  }
]
```

5. Redeploy after adding or changing environment variables.

Never put real API keys in source files or commit `.env.local`.

## API

- `GET /api/market?symbol=XAU%2FUSD`
- `GET /api/news`

## Build check

```bash
npm run build
```

If Twelve Data does not support a requested symbol/interval on your plan, the dashboard shows the provider's error rather than fabricating prices.
